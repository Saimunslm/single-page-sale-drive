import os
from dotenv import load_dotenv
from mongoengine import connect, get_connection
from flask import Flask

load_dotenv()

app = Flask(__name__)
uri = os.environ.get('MONGODB_URI')
print(f"Testing connection to: {uri.split('@')[1] if '@' in uri else 'Invalid URI structure'}")

try:
    # Attempt connection
    connect(host=uri)
    conn = get_connection()
    # verify connection by running a simple command
    conn.admin.command('ping')
    print("SUCCESS: Connected to MongoDB Atlas!")
except Exception as e:
    print(f"FAILURE: Could not connect to MongoDB. Error: {e}")
